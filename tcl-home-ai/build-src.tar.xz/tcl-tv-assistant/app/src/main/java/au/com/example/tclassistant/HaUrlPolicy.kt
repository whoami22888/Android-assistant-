package au.com.example.tclassistant

import java.net.URI

/** Only direct Home Assistant origins; local HTTP is an explicit lower-security option. */
object HaUrlPolicy {
    fun normalized(input: String): String {
        val url = try { URI(input.trim()) } catch (_: Exception) { null }
            ?: throw IllegalArgumentException("Enter a full URL, such as http://192.168.1.10:8123")
        val scheme = url.scheme?.lowercase()
        val host = url.host?.lowercase()
        require(scheme == "http" || scheme == "https") { "Only http and https are supported" }
        require(!host.isNullOrBlank() && url.userInfo == null) { "URL must have a valid host and no credentials" }
        require(url.query == null && url.fragment == null) { "Remove URL query and fragment" }
        require(url.path.isNullOrEmpty() || url.path == "/") { "Use the Home Assistant root address, without a path" }
        require(url.port in -1..65535 && url.port != 0) { "Invalid port" }
        if (scheme == "http") {
            require(isPrivateLocalHost(host)) {
                "Unencrypted HTTP is only permitted for a private LAN address; use HTTPS for remote hosts"
            }
        }
        return URI(scheme, null, host, url.port, null, null, null).toASCIIString().trimEnd('/')
    }

    private fun isPrivateLocalHost(host: String): Boolean {
        if (host == "localhost" || host == "[::1]" || host.endsWith(".local")) return true
        val parts = host.split('.')
        if (parts.size != 4 || parts.any { it.isEmpty() || it.length > 3 || it.any { c -> !c.isDigit() } }) return false
        val octets = parts.mapNotNull { it.toIntOrNull() }
        if (octets.size != 4 || octets.any { it !in 0..255 }) return false
        return octets[0] == 10 ||
            (octets[0] == 172 && octets[1] in 16..31) ||
            (octets[0] == 192 && octets[1] == 168) ||
            (octets[0] == 127)
    }
}
