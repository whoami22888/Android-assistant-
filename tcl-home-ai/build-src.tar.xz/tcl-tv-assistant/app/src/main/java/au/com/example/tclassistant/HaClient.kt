package au.com.example.tclassistant

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Minimal, single-purpose REST client. Never follows redirects with authorization. */
object HaClient {
    fun ask(baseUrl: String, token: String, prompt: String): String {
        val root = HaUrlPolicy.normalized(baseUrl)
        val url = URL("$root/api/conversation/process")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 7_000
            readTimeout = 25_000
            instanceFollowRedirects = false
            doOutput = true
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val body = JSONObject().put("text", prompt).put("language", "en").toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            if (status != 200) {
                throw IOException(
                    when (status) {
                        401, 403 -> "Authentication failed: check the Home Assistant token"
                        in 300..399 -> "Server redirected the request; check the Home Assistant URL"
                        else -> "Home Assistant returned HTTP $status"
                    }
                )
            }
            val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val chars = CharArray(4096)
                val output = StringBuilder()
                while (true) {
                    val count = reader.read(chars)
                    if (count < 0) break
                    if (output.length + count > 262_144) throw IOException("Home Assistant response is too large")
                    output.append(chars, 0, count)
                }
                output.toString()
            }
            val speech = JSONObject(response).optJSONObject("response")
                ?.optJSONObject("speech")?.optJSONObject("plain")?.optString("speech")
            return speech?.takeIf { it.isNotBlank() } ?: "Command sent, but Home Assistant returned no spoken reply."
        } finally { connection.disconnect() }
    }
}
