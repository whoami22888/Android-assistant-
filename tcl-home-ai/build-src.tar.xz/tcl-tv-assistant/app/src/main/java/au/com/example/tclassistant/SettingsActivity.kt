package au.com.example.tclassistant

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Toast

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val column = TvUi.column(this)
        val scroll = ScrollView(this).apply { addView(column) }
        setContentView(scroll)
        column.addView(TvUi.text(this, "Connect Home Assistant", 28f))
        column.addView(TvUi.text(this, "Enter the address of your Home Assistant SERVER, not your TCL TV's IP. Example: http://192.168.1.10:8123"))
        val urlEdit = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(Preferences.getUrl(this@SettingsActivity))
            hint = "Home Assistant URL"
            setTextColor(TvUi.FG)
            setHintTextColor(TvUi.MUTED)
        }
        column.addView(urlEdit)
        column.addView(TvUi.text(this, "Optional: long-lived access token. Required for AI/Assist commands, not for signing in to the dashboard."))
        val tokenEdit = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = if (Preferences.hasToken(this@SettingsActivity)) "Token stored — leave blank to keep" else "Paste access token"
            setTextColor(TvUi.FG)
            setHintTextColor(TvUi.MUTED)
        }
        column.addView(tokenEdit)
        column.addView(TvUi.button(this, "Save connection") {
            val url = try { HaUrlPolicy.normalized(urlEdit.text.toString()) } catch (e: IllegalArgumentException) {
                Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                return@button
            }
            val enteredToken = tokenEdit.text.toString().trim().takeIf { it.isNotEmpty() }
            val save = {
                try {
                    Preferences.save(this, url, enteredToken)
                    Toast.makeText(this, "Connection settings saved", Toast.LENGTH_SHORT).show()
                    finish()
                } catch (_: Exception) {
                    Toast.makeText(this, "Could not save encrypted token", Toast.LENGTH_LONG).show()
                }
            }
            if (url.startsWith("http://")) {
                AlertDialog.Builder(this)
                    .setTitle("Unencrypted local connection")
                    .setMessage("HTTP traffic, including a token, can be intercepted on this network. Use trusted Wi-Fi only. Prefer HTTPS when available.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Accept LAN risk") { _, _ -> save() }
                    .show()
            } else save()
        })
        column.addView(TvUi.button(this, "Remove stored API token") {
            AlertDialog.Builder(this)
                .setTitle("Remove token?")
                .setMessage("This removes only the assistant's saved token. It does not revoke the token in Home Assistant.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove") { _, _ ->
                    Preferences.clearToken(this)
                    tokenEdit.setText("")
                    tokenEdit.hint = "No token stored"
                }.show()
        })
        column.addView(TvUi.button(this, "Back to assistant") { finish() })
    }
}
