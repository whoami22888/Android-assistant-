package au.com.example.tclassistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var answer: TextView
    private lateinit var prompt: EditText
    private var tts: TextToSpeech? = null
    private var speechReady = false
    private var inFlight = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { result -> speechReady = result == TextToSpeech.SUCCESS }
        val column = TvUi.column(this)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(column) })
        column.addView(TvUi.text(this, "TCL Home AI", 32f))
        column.addView(TvUi.text(this, "Smart home + your original TCL TV. TV firmware and factory apps are untouched.", 17f))
        column.addView(TvUi.button(this, "Home Assistant Dashboard") {
            if (Preferences.getUrl(this).isBlank()) showSettingsHint()
            else startActivity(Intent(this, DashboardActivity::class.java))
        })
        column.addView(TvUi.button(this, "TV / HDMI Inputs") { openTvInputs() })
        column.addView(TvUi.button(this, "Installed TV Apps") { showAppPicker() })
        column.addView(TvUi.button(this, "Original Android TV Home") { openOriginalHome() })
        column.addView(TvUi.text(this, "Ask Home Assistant", 24f))
        prompt = EditText(this).apply {
            hint = "e.g. Turn on the living room lights"
            setSingleLine(true)
            setTextColor(TvUi.FG)
            setHintTextColor(TvUi.MUTED)
        }
        column.addView(prompt)
        column.addView(TvUi.button(this, "Send command") { sendQuestion(prompt.text.toString()) })
        column.addView(TvUi.button(this, "Speak command (if supported)") { startSpeechRecognition() })
        answer = TvUi.text(this, "AI uses your Home Assistant Assist conversation agent. Voice recognition requires a compatible installed TV speech service.")
        column.addView(answer)
        column.addView(TvUi.button(this, "Connection / Token Settings") { startActivity(Intent(this, SettingsActivity::class.java)) })
    }

    private fun showSettingsHint() {
        AlertDialog.Builder(this).setTitle("Home Assistant not connected")
            .setMessage("Configure the address of your separate Home Assistant server first.")
            .setPositiveButton("Settings") { _, _ -> startActivity(Intent(this, SettingsActivity::class.java)) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun sendQuestion(question: String) {
        val text = question.trim()
        if (text.isEmpty() || inFlight) return
        val server = Preferences.getUrl(this)
        val token = Preferences.getToken(this)
        if (server.isBlank() || token.isNullOrBlank()) {
            answer.text = "Set the Home Assistant address and API token in Settings first."
            return
        }
        inFlight = true
        answer.text = "Contacting Home Assistant..."
        thread(name = "HA conversation request") {
            val result = try { HaClient.ask(server, token, text) }
            catch (e: Exception) { "Command failed: ${e.message ?: "connection error"}" }
            ui.post {
                if (isFinishing || isDestroyed) return@post
                inFlight = false
                answer.text = result
                if (!result.startsWith("Command failed") && speechReady) {
                    tts?.speak(result, TextToSpeech.QUEUE_FLUSH, null, "ha_response")
                }
            }
        }
    }

    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-AU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask Home Assistant")
        }
        try { startActivityForResult(intent, 1001) }
        catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No voice-recognition app on this TV. Type your command instead.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Android 8-compatible activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                prompt.setText(spoken)
                sendQuestion(spoken)
            }
        }
    }

    private fun openTvInputs() {
        // The screenshots show this TCL package, but its launchability still needs real-device testing.
        val launch = packageManager.getLaunchIntentForPackage("com.tcl.sourcemanager")
            ?: packageManager.getLeanbackLaunchIntentForPackage("com.tcl.sourcemanager")
        if (launch != null) {
            try { startActivity(launch); return }
            catch (_: Exception) { /* Manufacturer may restrict access: use safe fallback. */ }
        }
        AlertDialog.Builder(this).setTitle("TCL input selection")
            .setMessage("The TCL SourceManager isn't publicly launchable. Use the INPUT / SOURCE button on the original TCL remote, or choose an installed TV app.")
            .setPositiveButton("Browse TV apps") { _, _ -> showAppPicker() }
            .setNegativeButton("Close", null).show()
    }

    private fun showAppPicker() {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val items = packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName + "/" + it.activityInfo.name }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.ROOT) }
        if (items.isEmpty()) {
            Toast.makeText(this, "No TV apps available to launch", Toast.LENGTH_LONG).show()
            return
        }
        val names = items.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Installed TV apps")
            .setItems(names) { _, which ->
                val activity = items[which].activityInfo
                try { startActivity(Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
                    setClassName(activity.packageName, activity.name)
                }) }
                catch (_: Exception) { Toast.makeText(this, "Cannot open this app", Toast.LENGTH_LONG).show() }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun openOriginalHome() {
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }
        catch (_: Exception) { Toast.makeText(this, "Use the HOME button on your original remote", Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
