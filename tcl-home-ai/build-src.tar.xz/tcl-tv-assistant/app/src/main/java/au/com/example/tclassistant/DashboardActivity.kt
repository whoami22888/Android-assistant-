package au.com.example.tclassistant

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.SslErrorHandler
import android.net.http.SslError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/** Display HA's own authentication page. Never inject the assistant API token into WebView. */
class DashboardActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var expectedOrigin: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = try { HaUrlPolicy.normalized(Preferences.getUrl(this)) } catch (_: Exception) { finish(); return }
        expectedOrigin = Uri.parse(url)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isFocusableInTouchMode = true
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return request.isForMainFrame && !isSameOrigin(request.url)
                }
                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                    handler.cancel() // Never disable SSL verification.
                    Toast.makeText(this@DashboardActivity, "HTTPS certificate error — page blocked", Toast.LENGTH_LONG).show()
                }
            }
        }
        setContentView(web)
        web.loadUrl(url)
    }

    private fun isSameOrigin(uri: Uri): Boolean =
        uri.scheme.equals(expectedOrigin.scheme, true) &&
            uri.host.equals(expectedOrigin.host, true) &&
            effectivePort(uri) == effectivePort(expectedOrigin)

    private fun effectivePort(uri: Uri): Int = if (uri.port > 0) uri.port else if (uri.scheme == "https") 443 else 80

    @Deprecated("Android 8 compatible back-navigation")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web.stopLoading()
        web.destroy()
        super.onDestroy()
    }
}
