package au.com.example.tclassistant

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object TvUi {
    const val BACKGROUND = 0xFF102233.toInt()
    const val FG = 0xFFE9FAFF.toInt()
    const val MUTED = 0xFFACCAD9.toInt()
    const val HIGHLIGHT = 0xFF30D6B5.toInt()

    fun column(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(28, 28, 28, 28)
        setBackgroundColor(BACKGROUND)
    }

    fun text(context: Context, value: String, size: Float = 18f): TextView = TextView(context).apply {
        text = value
        textSize = size
        setTextColor(FG)
        setPadding(0, 12, 0, 12)
    }

    fun button(context: Context, value: String, onClick: (View) -> Unit): Button = Button(context).apply {
        text = value
        isAllCaps = false
        textSize = 20f
        minHeight = 76
        isFocusable = true
        setTextColor(FG)
        setOnClickListener(onClick)
        setOnFocusChangeListener { _, focused ->
            background = backgroundFor(focused)
            setTextColor(if (focused) BACKGROUND else FG)
        }
        background = backgroundFor(false)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 12
        layoutParams = lp
    }

    private fun backgroundFor(focused: Boolean): GradientDrawable = GradientDrawable().apply {
        setColor(if (focused) HIGHLIGHT else 0xFF25455D.toInt())
        cornerRadius = 16f
        setStroke(2, if (focused) Color.WHITE else 0xFF466D81.toInt())
    }
}
