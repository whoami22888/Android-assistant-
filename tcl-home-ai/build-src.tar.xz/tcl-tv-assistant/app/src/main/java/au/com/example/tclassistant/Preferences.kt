package au.com.example.tclassistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object Preferences {
    private const val FILE = "tcl_ha_prefs"
    private const val ALIAS = "tcl_ha_token_v1"
    private const val KEY_URL = "url"
    private const val KEY_TOKEN = "token_enc"

    fun getUrl(context: Context): String = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        .getString(KEY_URL, "") ?: ""

    fun save(context: Context, url: String, token: String?) {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val editor = prefs.edit().putString(KEY_URL, url)
        // Never reuse a bearer token when changing server origins.
        if (prefs.getString(KEY_URL, "") != url) editor.remove(KEY_TOKEN)
        if (!token.isNullOrBlank()) editor.putString(KEY_TOKEN, encrypt(token.trim()))
        editor.apply()
    }

    fun hasToken(context: Context): Boolean = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        .contains(KEY_TOKEN)

    fun getToken(context: Context): String? {
        val encoded = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_TOKEN, null) ?: return null
        return try {
            val all = Base64.decode(encoded, Base64.NO_WRAP)
            if (all.size < 13) return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
            String(cipher.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }

    fun clearToken(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(KEY_TOKEN).apply()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }
}
